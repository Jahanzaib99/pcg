<?php $__env->startSection('css_before'); ?>
    <!-- Page JS Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('js/plugins/datatables/dataTables.bootstrap4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/plugins/datatables/buttons-bs4/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>
    <!-- Page JS Plugins -->
    <script src="<?php echo e(asset('js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables/buttons/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables/buttons/buttons.colVis.min.js')); ?>"></script>

    <!-- Page JS Code -->
    <script src="<?php echo e(asset('js/pages/tables_datatables.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero -->
    <div class="bg-body-light">
        <div class="content content-full">
            <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
                <h1 class="flex-sm-fill font-size-h2 font-w400 mt-2 mb-0 mb-sm-2">BASE SET CARDS</h1>
                
                
                
                
                
                
            </div>
        </div>
    </div>
    <!-- END Hero -->

    <!-- Page Content -->
    <div class="content">
        <!-- Info -->
    
    
    
    
    
    
    
    
    
    
    <!-- END Info -->

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Cards <small></small></h3>
            </div>
            <div class="block-content block-content-full">
                <!-- DataTables init on table by adding .js-dataTable-full class, functionality is initialized in js/pages/tables_datatables.js -->
                <table class="table table-bordered table-striped table-vcenter js-dataTable-full">
                    <thead>
                    <tr>
                        <th class="text-center" style="width: 80px;">#</th>
                        <th>Name</th>
                        <th class="d-none d-sm-table-cell" style="width: 30%;">Last sale</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($index+1); ?></td>
                            <td class="font-w600">
                                <a href="<?php echo e(route('collection.card.detail', $card->id)); ?>"><?php echo e($card->name); ?></a>
                            </td>
                            <td class="d-none d-sm-table-cell">
                                <?php
                                $cardDetail = \App\Models\CardDetail::select('price')->where('card_id', $card->id)->orderBy('sale_date', 'desc')->first();
                                ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\workspace\laravel\twolucky-projects\resources\views/collection_cards.blade.php ENDPATH**/ ?>