<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <div class="content">

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title"><b>Edit Card</b></h3>
            </div>
            <div class="block-content block-content-full">'
                <form action="<?php echo e(route('card.update')); ?>" method="post" enctype="multipart/form-data"  novalidate>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-group">
                            <label for="example-email-input">Set</label>
                            <select name="set_id" id="set_id" class="form-control">
                                <option disabled> select set</option>
                                <?php $__currentLoopData = $sets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($set->id); ?>" <?php echo e($card->set_id == $set->id ? 'selected="selected"' : ''); ?>><?php echo e($set->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="example-text-input">Name</label>
                            <input type="text" class="form-control" id="name" name="name"
                                   placeholder="Enter name" value="<?php echo e(isset($card->name) ? $card['name'] : ""); ?>">
                        </div>

                    </div>
                    <div class="text-right">
                        <input type="submit" class="btn btn-primary" value="Update">
                    </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\workspace\laravel\twolucky-projects\resources\views/card/update.blade.php ENDPATH**/ ?>