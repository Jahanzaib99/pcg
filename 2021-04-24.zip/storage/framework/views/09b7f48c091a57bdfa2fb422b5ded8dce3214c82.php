<?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <div class="content">

        <!-- Dynamic Table Full -->
        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title"><b>Add Set</b></h3>
            </div>
            <div class="block-content block-content-full">'
                <form action="<?php echo e(route('set.store')); ?>" method="post" enctype="multipart/form-data"  novalidate>
                    <?php echo csrf_field(); ?>
                <div class="col-lg-12 col-xl-6">
                    <div class="form-group">
                        <label for="example-text-input">Name</label>
                        <input type="text" class="form-control" id="name" name="name"
                               placeholder="Enter name">
                    </div>
                    <div class="form-group">
                        <label for="example-email-input">Image</label>
                        <input type="file" class="form-control" id="image" name="image"
                               placeholder="Choose an image">
                    </div>

                </div>
                <div class="text-right">
                    <input type="submit" class="btn btn-primary" value="Save">
                </div>
            </div>
        </div>
        <!-- END Dynamic Table Full -->
    </div>
    <!-- END Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\workspace\laravel\twolucky-projects\resources\views/set/add.blade.php ENDPATH**/ ?>